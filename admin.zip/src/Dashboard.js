import React from 'react';
import { Card, CardContent, CardHeader } from '@mui/material';

export default () => {

  return (
    <Card style={{ backgroundColor: '#f5f5f5', margin: '20px' }}>
      <CardHeader title="Welcome to Guest Lecture Management System Admin" style={{ backgroundColor: '#3f51b5', color: 'white', textAlign: 'center' }} />
      <CardContent>
        <p style={{ textAlign: 'center', marginTop: '20px', fontSize: '18px', fontWeight: 'bold', color: '#3f51b5' }}>
          Have a great day, Boss!
        </p>
      </CardContent>
    </Card>
  );
};
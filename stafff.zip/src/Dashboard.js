import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@mui/material';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';

export default () => {
  const [events, setEvents] = useState([]);

  useEffect(() => {
    // Fetch events data from the JSON server or any other data source
    fetch('https://your-json-server/events')
      .then(response => response.json())
      .then(data => setEvents(data))
      .catch(error => console.error(error));
  }, []);

  return (
    <Card style={{ backgroundColor: '#f5f5f5', margin: '20px' }}>
      <CardHeader
        title="Welcome to Guest Lecture Management System Admin"
        style={{ backgroundColor: '#3f51b5', color: 'white', textAlign: 'center' }}
      />
      <CardContent>
        <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
          <div>
            <h2>Calendar</h2>
            <Calendar />
          </div>
          <div style={{ marginBottom: 'center' }}>
            <h2>Upcoming Events</h2>
            <table>
              <thead>
                <tr>
                  <th style={{ paddingRight: '100px' }}>Title</th>
                  <th style={{ paddingRight: '100px' }}>Date</th>
                  <th style={{ paddingRight: '200px' }}>Description</th>
                </tr>
              </thead>
              <tbody>
                {events.map(event => (
                  <tr key={event.id}>
                    <td>{event.title}</td>
                    <td>{event.date}</td>
                    <td>{event.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

import * as React from "react";
import { Admin, Resource } from "react-admin";
import { UserList } from "./users";
import { CourseCreate, CourseEdit, CourseList } from "./Course";
import PostIcon from '@mui/icons-material/Book';
import UserIcon from '@mui/icons-material/Group';
import Dashboard from "./Dashboard";
import authProvider from "./authProvider";

// Dummy JSON data
const dummyCourses = [
  { id: 1, User: 1, title: "Dummy Course 1", body: "Lorem ipsum dolor sit amet" },
  { id: 2, User: 2, title: "Dummy Course 2", body: "Lorem ipsum dolor sit amet" },
];

const dummyUsers = [
  { id: 1, name: "John Doe" },
  { id: 2, name: "Jane Smith" },
];

const dataProvider = {
  getList: (resource, params) => {
    const { page, perPage } = params.pagination;
    const start = (page - 1) * perPage;
    const end = page * perPage;
    let data = [];

    if (resource === "courses") {
      data = dummyCourses.slice(start, end);
      return Promise.resolve({
        data: data,
        total: dummyCourses.length,
      });
    }

    if (resource === "users") {
      data = dummyUsers.slice(start, end);
      return Promise.resolve({
        data: data,
        total: dummyUsers.length,
      });
    }

    return Promise.reject(new Error("Resource not found"));
  },

  getOne: (resource, params) => {
    let item = null;
  
    if (resource === "courses") {
      const id = parseInt(params.id); // Make sure id is a valid integer value
      if (!isNaN(id)) {
        item = dummyCourses.find((c) => c.id === id);
      }
    }
  
    if (resource === "users") {
      item = dummyUsers.find((u) => u.id === params.id);
    }
  
    if (item) {
      return Promise.resolve({
        data: { ...item },
      });
    }
  
    return Promise.reject(new Error("Item not found"));
  },

  getMany: (resource, params) => {
    const { ids } = params;
    let data = [];

    if (resource === "courses") {
      data = dummyCourses.filter((course) => ids.includes(course.id));
      return Promise.resolve({ data });
    }

    if (resource === "users") {
      data = dummyUsers.filter((user) => ids.includes(user.id));
      return Promise.resolve({ data });
    }

    return Promise.reject(new Error("Resource not found"));
  },
  create: (resource, params) => {
    if (resource === "users") {
      const newUser = { ...params.data, id: dummyUsers.length + 1 };
      dummyUsers.push(newUser);
      return Promise.resolve({ data: newUser });
    }

    return Promise.reject(new Error("Resource not found"));
  },

  update: (resource, params) => {
    if (resource === "users") {
      const { id, ...updateData } = params.data;
      const userIndex = dummyUsers.findIndex((user) => user.id === id);

      if (userIndex !== -1) {
        dummyUsers[userIndex] = { ...dummyUsers[userIndex], ...updateData };
        return Promise.resolve({ data: dummyUsers[userIndex] });
      }
    }

    return Promise.reject(new Error("Item not found"));
  },

  deleteMany: (resource, params) => {
    if (resource === "users") {
      const { ids } = params;
      const deletedUsers = [];

      ids.forEach((id) => {
        const userIndex = dummyUsers.findIndex((user) => user.id === id);

        if (userIndex !== -1) {
          const deletedUser = dummyUsers.splice(userIndex, 1);
          deletedUsers.push(deletedUser[0]);
        }
      });

      return Promise.resolve({ data: deletedUsers });
    }

    return Promise.reject(new Error("Resource not found"));
  },
  
  // Implement create, update, delete methods in a similar manner
};

const App = () => (
  <Admin dashboard={Dashboard} authProvider={authProvider} dataProvider={dataProvider}>
    <Resource name="courses" list={CourseList} edit={CourseEdit} create={CourseCreate} icon={PostIcon} />
    <Resource name="users" list={UserList} icon={UserIcon} />
  </Admin>
);


export default App;
